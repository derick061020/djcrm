<?php

namespace App\Filament\Resources\FormatosResource\Pages;

use App\Filament\Resources\FormatosResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFormatos extends CreateRecord
{
    protected static string $resource = FormatosResource::class;
}
