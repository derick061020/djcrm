<!DOCTYPE html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta charset="utf-8" />
</head>

<body style="margin: 0;">

<div id="p3" style="overflow: hidden; position: relative; background-color: white; width: 2200px; height: 1237px;">
<style class="shared-css" type="text/css" >
.t {
	transform-origin: bottom left;
	z-index: 2;
	position: absolute;
	white-space: pre;
	overflow: visible;
	line-height: 1.5;
}
.text-container {
	white-space: pre;
}
@supports (-webkit-touch-callout: none) {
	.text-container {
		white-space: normal;
	}
}
</style>
<style type="text/css" >

#t1_3{left:1517px;bottom:881px;letter-spacing:0.05px;}
#t2_3{left:1364px;bottom:820px;letter-spacing:0.04px;}
#t3_3{left:1331px;bottom:671px;letter-spacing:-0.12px;}
#t4_3{left:1440px;bottom:606px;letter-spacing:-0.12px;}
#t5_3{left:1347px;bottom:485px;letter-spacing:-0.11px;}
#t6_3{left:1329px;bottom:378px;letter-spacing:-0.13px;}
#t7_3{left:1378px;bottom:313px;letter-spacing:-0.12px;}
#t8_3{left:124px;bottom:507px;letter-spacing:-0.11px;}
#t9_3{left:124px;bottom:715px;letter-spacing:-0.02px;}
#ta_3{left:124px;bottom:602px;letter-spacing:-0.02px;}

.s0_3{font-size:44px;font-family:AyrLucidityExpand-Regular_ez;color:#FFF;}
.s1_3{font-size:41px;font-family:Poppins-Regular_e-;color:#FFF;}
.s2_3{font-size:41px;font-family:Rubik-Regular_f0;color:#FFF;}
.s3_3{font-size:43px;font-family:Poppins-Regular_e-_1;color:rgba(255,255,255,0.8);}
.s4_3{font-size:81px;font-family:Poppins-Bold_f1;color:#F0F28F;}
</style>
<style id="fonts3" type="text/css" >

@font-face {
	font-family: AyrLucidityExpand-Regular_ez;
	src: url("../fonts/AyrLucidityExpand-Regular_ez.woff") format("woff");
}

@font-face {
	font-family: Poppins-Bold_f1;
	src: url("../fonts/Poppins-Bold_f1.woff") format("woff");
}

@font-face {
	font-family: Poppins-Regular_e-;
	src: url("../fonts/Poppins-Regular_e-.woff") format("woff");
}

@font-face {
	font-family: Poppins-Regular_e-_1;
	src: url("../fonts/Poppins-Regular_e-_1.woff") format("woff");
}

@font-face {
	font-family: Rubik-Regular_f0;
	src: url("../fonts/Rubik-Regular_f0.woff") format("woff");
}

</style>
<div id="pg3Overlay" style="width:100%; height:100%; position:absolute; z-index:1; background-color:rgba(0,0,0,0); -webkit-user-select: none;"></div>
<div id="pg3" style="-webkit-user-select: none;"><object width="2200" height="1237" data="../3/3.svg" type="image/svg+xml" id="pdf3" style="width:2200px; height:1237px; z-index: 0;"></object></div>
<div class="text-container"><span id="t1_3" class="t s0_3">DJ </span>
<span id="t2_3" class="t s0_3">BUSINESS </span>
<span id="t3_3" class="t s1_3">Especialista en eventos </span>
<span id="t4_3" class="t s1_3">corporativos </span>
<span id="t5_3" class="t s2_3">+ 7 años de experiencia </span>
<span id="t6_3" class="t s1_3">Habilidad para mezclar </span>
<span id="t7_3" class="t s1_3">diferentes géneros </span>
<span id="t8_3" class="t s3_3">El perfil del artista corresponde al siguiente: </span>
<span id="t9_3" class="t s4_3">El DJ que necesitas </span>
<span id="ta_3" class="t s4_3">para tu empresa </span></div>

</div>
</body>
</html>
