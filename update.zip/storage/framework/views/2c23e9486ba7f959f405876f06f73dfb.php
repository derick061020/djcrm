<!DOCTYPE html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta charset="utf-8" />
</head>

<body style="margin: 0;">

<div id="p5" style="overflow: hidden; position: relative; background-color: white; width: 2200px; height: 1237px;">
<style class="shared-css" type="text/css" >
.t {
	transform-origin: bottom left;
	z-index: 2;
	position: absolute;
	white-space: pre;
	overflow: visible;
	line-height: 1.5;
}
.text-container {
	white-space: pre;
}
@supports (-webkit-touch-callout: none) {
	.text-container {
		white-space: normal;
	}
}
</style>
<style type="text/css" >

#t1_5{left:97px;bottom:836px;letter-spacing:-2.54px;}
#t2_5{left:97px;bottom:743px;letter-spacing:-2.53px;}
#t3_5{left:97px;bottom:635px;letter-spacing:-1.43px;word-spacing:7.25px;}
#t4_5{left:97px;bottom:583px;letter-spacing:-1.44px;word-spacing:9.04px;}
#t5_5{left:97px;bottom:532px;letter-spacing:-1.43px;word-spacing:7.81px;}
#t6_5{left:97px;bottom:480px;letter-spacing:-1.43px;word-spacing:12.97px;}
#t7_5{left:97px;bottom:429px;letter-spacing:-1.45px;word-spacing:21.34px;}
#t8_5{left:97px;bottom:377px;letter-spacing:-1.4px;}
#t9_5{left:97px;bottom:274px;letter-spacing:-1.41px;word-spacing:4.27px;}
#ta_5{left:97px;bottom:222px;letter-spacing:-1.4px;}
#tb_5{left:90px;bottom:968px;letter-spacing:-1.54px;}

.s0_5{font-size:78px;font-family:Poppins-Bold_bb;color:#F4F0ED;}
.s1_5{font-size:38px;font-family:Poppins-Regular_bc;color:#F4F0ED;}
.s2_5{font-size:46px;font-family:Poppins-Bold_bb;color:#F0E07F;}
</style>
<style id="fonts5" type="text/css" >

@font-face {
	font-family: Poppins-Bold_bb;
	src: url("../fonts/Poppins-Bold_bb.woff") format("woff");
}

@font-face {
	font-family: Poppins-Regular_bc;
	src: url("../fonts/Poppins-Regular_bc.woff") format("woff");
}

</style>
<div id="pg5Overlay" style="width:100%; height:100%; position:absolute; z-index:1; background-color:rgba(0,0,0,0); -webkit-user-select: none;"></div>
<div id="pg5" style="-webkit-user-select: none;"><object width="2200" height="1237" data="../5/5.svg" type="image/svg+xml" id="pdf5" style="width:2200px; height:1237px; z-index: 0;"></object></div>
<div class="text-container"><span id="t1_5" class="t s0_5">El toque mágico para </span>
<span id="t2_5" class="t s0_5">iluminar tu gran día </span>
<span id="t3_5" class="t s1_5">Haz que el cumpleaños sea inolvidable con </span>
<span id="t4_5" class="t s1_5">unas bengalas que llenará el momento de </span>
<span id="t5_5" class="t s1_5">luz y magia. Cada chispa será parte de un </span>
<span id="t6_5" class="t s1_5">recuerdo especial, creando una atmósfera </span>
<span id="t7_5" class="t s1_5">única para celebrar a esa persona tan </span>
<span id="t8_5" class="t s1_5">especial. </span>
<span id="t9_5" class="t s1_5">Llevaremos 10 bengalas para que las utilices </span>
<span id="ta_5" class="t s1_5">como quieras durante la fiesta. </span>
<span id="tb_5" class="t s2_5">¡Te lo incluimos gratis! </span></div>

</div>
</body>
</html>
<?php /**PATH /home/kira/Escritorio/projects/djCrm/resources/views/presupuesto/5.blade.php ENDPATH**/ ?>