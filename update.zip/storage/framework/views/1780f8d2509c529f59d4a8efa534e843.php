<!DOCTYPE html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta charset="utf-8" />

</head>

<body style="margin: 0;">

<div id="p1" style="overflow: hidden; position: relative; background-color: white; width: 2200px; height: 1237px;">
<?php
use Illuminate\Support\Str;
?>
<style class="shared-css" type="text/css" >
.t {
	transform-origin: bottom left;
	z-index: 2;
	position: absolute;
	white-space: pre;
	overflow: visible;
	line-height: 1.5;
}
.text-container {
	white-space: pre;
}
@supports (-webkit-touch-callout: none) {
	.text-container {
		white-space: normal;
	}
}
</style>

<style type="text/css" >

#t1_1{left:1930px;bottom:21px;letter-spacing:-0.13px;}
#t2_1{left:381px;bottom:602px;letter-spacing:-0.17px;}
#t3_1{left:40px;bottom:22px;letter-spacing:10.41px;}
#t4_1{left:533px;bottom:532px;letter-spacing:9.22px;}
#t5_1{left:873px;bottom:485px;letter-spacing:9.24px;}

.s0_1{font-size:40px;font-family:RedHatDisplay-Regular_b3;color:#FFF;}
.s1_1{font-size:121px;font-family:Poppins-Regular_b4;color:#FFF;}
.s2_1{font-size:34px;font-family:RedHatDisplay-Regular_b3;color:#FFF;}
.s3_1{font-size:43px;font-family:RedHatDisplay-Regular_b3;color:#FFF;}
</style>
<style id="fonts1" type="text/css" >

@font-face {
	font-family: Poppins-Regular_b4;
	src: url("../fonts/Poppins-Regular_b4.woff") format("woff");
}

@font-face {
	font-family: RedHatDisplay-Regular_b3;
	src: url("../fonts/RedHatDisplay-Regular_b3.woff") format("woff");
}

</style>
<div id="pg1Overlay" style="width:100%; height:100%; position:absolute; z-index:1; background-color:rgba(0,0,0,0); -webkit-user-select: none;"></div>
<div id="pg1" style="-webkit-user-select: none;"><object width="2200" height="1237" data="/storage/<?php echo e($formato->data['image_page_1']); ?>" type="image/svg+xml" id="pdf1" style="width:2200px; height:1237px; z-index: 0;"></object></div>
<div class="text-container"><span id="t1_1" class="t s0_1">www.lafest.es </span>
<span id="t2_1" class="t s1_1"><?php echo e($formato->data['title_page_1']); ?> <?php echo e($cliente->nombre); ?> </span>
<span id="t3_1" class="t s2_1">LAFEST </span>
<span id="t4_1" class="t s3_1"><?php echo e(substr($formato->data['slogan_page_1'], 0, 34)); ?></span>
<span id="t5_1" class="t s3_1"><?php echo e(substr($formato->data['slogan_page_1'], 34)); ?></span></div>

</div>
</body>

</html>
<?php /**PATH /home/kira/Escritorio/projects/djCrm/resources/views/presupuesto/1.blade.php ENDPATH**/ ?>