<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\CrmPanelProvider::class,
];
