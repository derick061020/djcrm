<!DOCTYPE html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta charset="utf-8" />
</head>

<body style="margin: 0;">

<div id="p1" style="overflow: hidden; position: relative; background-color: white; width: 2200px; height: 1237px;">
<style class="shared-css" type="text/css" >
.t {
	transform-origin: bottom left;
	z-index: 2;
	position: absolute;
	white-space: pre;
	overflow: visible;
	line-height: 1.5;
}
.text-container {
	white-space: pre;
}
@supports (-webkit-touch-callout: none) {
	.text-container {
		white-space: normal;
	}
}
</style>
<style type="text/css" >

#t1_1{left:133px;bottom:786px;letter-spacing:-0.18px;}
#t2_1{left:133px;bottom:676px;letter-spacing:-0.16px;}
#t3_1{left:382px;bottom:676px;letter-spacing:-0.14px;}
#t4_1{left:133px;bottom:382px;letter-spacing:0.07px;}
#t5_1{left:93px;bottom:51px;letter-spacing:-0.26px;}

.s0_1{font-size:66px;font-family:Poppins-Bold_fv;color:rgba(255,255,255,0.9);}
.s1_1{font-size:66px;font-family:Poppins-Bold_fv;color:rgba(240,242,143,0.9);}
.s2_1{font-size:25px;font-family:Poppins-Regular_ev;color:#CCC;}
.s3_1{font-size:31px;font-family:Poppins-Regular_ev;color:#FFF;}
</style>
<style id="fonts1" type="text/css" >

@font-face {
	font-family: Poppins-Bold_fv;
	src: url("../fonts/Poppins-Bold_fv.woff") format("woff");
}

@font-face {
	font-family: Poppins-Regular_ev;
	src: url("../fonts/Poppins-Regular_ev.woff") format("woff");
}

</style>
<div id="pg1Overlay" style="width:100%; height:100%; position:absolute; z-index:1; background-color:rgba(0,0,0,0); -webkit-user-select: none;"></div>
<div id="pg1" style="-webkit-user-select: none;"><object width="2200" height="1237" data="../1/1.svg" type="image/svg+xml" id="pdf1" style="width:2200px; height:1237px; z-index: 0;"></object></div>
<div class="text-container"><span id="t1_1" class="t s0_1">Juntos haremos que tu </span>
<span id="t2_1" class="t s1_1">evento </span><span id="t3_1" class="t s0_1">brille </span>
<span id="t4_1" class="t s2_1">Haz que tu evento sea un éxito como lo han hecho otras empresas </span>
<span id="t5_1" class="t s3_1">www.lafest.es </span></div>

</div>
</body>
</html>
