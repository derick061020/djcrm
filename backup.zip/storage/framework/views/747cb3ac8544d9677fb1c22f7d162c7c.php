<!DOCTYPE html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta charset="utf-8" />
</head>

<body style="margin: 0;">

<div id="p2" style="overflow: hidden; position: relative; background-color: white; width: 2200px; height: 1237px;">
<style class="shared-css" type="text/css" >
.t {
	transform-origin: bottom left;
	z-index: 2;
	position: absolute;
	white-space: pre;
	overflow: visible;
	line-height: 1.5;
}
.text-container {
	white-space: pre;
}
@supports (-webkit-touch-callout: none) {
	.text-container {
		white-space: normal;
	}
}
</style>
<style type="text/css" >

#t1_2{left:228px;bottom:921px;letter-spacing:-2.96px;}
#t2_2{left:228px;bottom:1072px;letter-spacing:11.5px;}
#t3_2{left:1361px;bottom:943px;letter-spacing:-1.06px;}
#t4_2{left:1322px;bottom:888px;letter-spacing:-1.06px;}
#t5_2{left:428px;bottom:771px;letter-spacing:-1.27px;}
#t6_2{left:428px;bottom:518px;letter-spacing:-1.28px;}
#t7_2{left:428px;bottom:223px;letter-spacing:-1.27px;}
#t8_2{left:428px;bottom:730px;letter-spacing:-0.91px;}
#t9_2{left:428px;bottom:693px;letter-spacing:-0.92px;}
#ta_2{left:428px;bottom:476px;letter-spacing:-0.91px;word-spacing:2.08px;}
#tb_2{left:428px;bottom:440px;letter-spacing:-0.92px;}
#tc_2{left:428px;bottom:178px;letter-spacing:-0.92px;}

.s0_2{font-size:86px;font-family:Poppins-SemiBold_b5;color:#F4F0ED;}
.s1_2{font-size:31px;font-family:Poppins-Regular_b6;color:#F4F0ED;}
.s2_2{font-size:33px;font-family:Poppins-Regular_b6;color:#F4F0ED;}
.s3_2{font-size:34px;font-family:Poppins-SemiBold_b5;color:#3D2313;}
.s4_2{font-size:27px;font-family:Poppins-Regular_b6;color:#3D2313;}
</style>
<style id="fonts2" type="text/css" >

@font-face {
	font-family: Poppins-Regular_b6;
	src: url("../fonts/poppins-regular-webfont.woff2") format("woff");
}

@font-face {
	font-family: Poppins-SemiBold_b5;
	src: url("../fonts/poppins-regular-webfont.woff2") format("woff");
}

</style>
<div id="pg2Overlay" style="width:100%; height:100%; position:absolute; z-index:1; background-color:rgba(0,0,0,0); -webkit-user-select: none;"></div>
<div id="pg2" style="-webkit-user-select: none;"><object width="2200" height="1237" data="../2/2.svg" type="image/svg+xml" id="pdf2" style="width:2200px; height:1237px; z-index: 0;"></object></div>
<div class="text-container"><span id="t1_2" class="t s0_2">Requisitos del evento </span>
<span id="t2_2" class="t s1_2">FECHA: 08 DE NOVIEMBRE DEL 2025 </span>
<span id="t3_2" class="t s2_2">Cualquier petición que tengas, no dudes en </span>
<span id="t4_2" class="t s2_2">comentárnoslo e intentaremos hacerla realidad. </span>
<span id="t5_2" class="t s3_2">Localización </span>
<span id="t6_2" class="t s3_2">Preferencias musicales </span>
<span id="t7_2" class="t s3_2">Asistentes </span>
<span id="t8_2" class="t s4_2">La localización del evento será en Castelldefels, </span>
<span id="t9_2" class="t s4_2">Barcelona. </span>
<span id="ta_2" class="t s4_2">La selección musical abarcará todo tipo de hits </span>
<span id="tb_2" class="t s4_2">de música pop, reggaeton. </span>
<span id="tc_2" class="t s4_2">Asistirán aproximadamente 45 invitados. </span></div>

</div>
</body>
</html>
<?php /**PATH /home/pulso/public_html/resources/views/presupuesto/2.blade.php ENDPATH**/ ?>