<?php echo e($slot); ?>

<?php /**PATH /home/kira/Escritorio/projects/djCrm/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>